package course.notification.admin;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@SpringBootApplication(scanBasePackages = "course")
@MapperScan("course.notification.mappers")
@EnableTransactionManagement
@EnableScheduling
public class NotificationAdminRunApplication {
    public static void main(String[] args) {
        SpringApplication.run(NotificationAdminRunApplication.class, args);
    }
}
