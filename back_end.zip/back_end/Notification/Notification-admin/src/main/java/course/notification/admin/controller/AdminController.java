package course.notification.admin.controller;

import course.notification.component.RedisComponent;
import course.notification.entity.dto.TokenUserInfoDto;
import course.notification.entity.enums.UserRoleEnum;
import course.notification.entity.po.CheckTable;
import course.notification.entity.po.UserInfo;
import course.notification.entity.query.CheckTableQuery;
import course.notification.entity.query.UserInfoQuery;
import course.notification.entity.vo.AnnouncementsVo;
import course.notification.entity.vo.CheckTableVo;
import course.notification.entity.vo.PaginationResultVO;
import course.notification.entity.vo.ResponseVO;
import course.notification.exception.BusinessException;
import course.notification.service.AnnouncementsService;
import course.notification.service.CheckTableService;
import course.notification.service.UserInfoService;
import org.springframework.web.HttpRequestHandler;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.validation.constraints.NotEmpty;
import java.util.List;

@RestController("adminController")
@RequestMapping("/admin")
public class AdminController extends ABaseController {
    @Resource
    private UserInfoService userInfoService;

    @Resource
    private CheckTableService checkTableService;

    @Resource
    private AnnouncementsService announcementsService;

    @Resource
    private RedisComponent redisComponent;

    @GetMapping("/loadDataList")
    public ResponseVO loadDataList(HttpServletRequest request,
                                   @RequestBody UserInfoQuery query){
       try {
           String userId = getTokenUserInfo(request).getUserId();
           UserInfo userInfo = userInfoService.getUserInfoByUserId(userId);
           if (userInfo == null) {
               return getBusinessErrorResponseVO(new BusinessException("用户不存在"), "用户不存在");
           }
           if (!userInfo.getRole().equals(UserRoleEnum.ADMIN.getType())) {
               return getBusinessErrorResponseVO(new BusinessException("权限不足"), "加载数据失败");
           }
           return getSuccessResponseVO(userInfoService.findListByPage(query));
       } catch (BusinessException e) {
           return getBusinessErrorResponseVO(e, "加载数据失败");
       }
    }

    @GetMapping("/getUserInfoByUserId")
    public ResponseVO getUserInfoByUserId(HttpServletRequest request,
                                          @NotEmpty String userId) {
        try {
            String uid = getTokenUserInfo(request).getUserId();
            UserInfo userInfo = userInfoService.getUserInfoByUserId(uid);
            if (userInfo == null) {
                return getBusinessErrorResponseVO(new BusinessException("用户不存在"), "用户不存在");
            }
            if (!userInfo.getRole().equals(UserRoleEnum.ADMIN.getType())) {
                return getBusinessErrorResponseVO(new BusinessException("权限不足"), "加载数据失败");
            }
            return getSuccessResponseVO(userInfoService.getUserInfoByUserId(userId));
        } catch (BusinessException e) {
            return getBusinessErrorResponseVO(e, "加载数据失败");
        }
    }

    // 修改用户状态和角色根据userId
    @PutMapping("/updateUserInfoByUserId")
    public ResponseVO updateUserInfoByUserId(HttpServletRequest request,
                                             @NotEmpty String userId,
                                             Integer status,
                                             Integer role) {
        try {
            String uid = getTokenUserInfo(request).getUserId();
            UserInfo userInfo = userInfoService.getUserInfoByUserId(uid);
            if (userInfo == null) {
                return getBusinessErrorResponseVO(new BusinessException("用户不存在"), "用户不存在");
            }
            if (!userInfo.getRole().equals(UserRoleEnum.ADMIN.getType())) {
                return getBusinessErrorResponseVO(new BusinessException("权限不足"), "加载数据失败");
            }
            UserInfo bean = new UserInfo();
            bean.setUserId(userId);
            bean.setStatus(status);
            bean.setRole(role);
            userInfoService.updateUserInfoByUserId(bean, userId);
            return getSuccessResponseVO("更新成功");

        } catch (BusinessException e) {
            return getBusinessErrorResponseVO(e, "更新失败");
        }
    }

    // 获取审批列表
    @GetMapping("/getApproveList")
    public ResponseVO getApproveList(HttpServletRequest request,
                                     @NotEmpty Integer pageNum,
                                     @NotEmpty Integer pageSize) {
        try {
            String userId = getTokenUserInfo(request).getUserId();
            UserInfo userInfo = userInfoService.getUserInfoByUserId(userId);
            if (userInfo == null) {
                return getBusinessErrorResponseVO(new BusinessException("用户不存在"), "用户不存在");
            }
            if (!userInfo.getRole().equals(UserRoleEnum.ADMIN.getType())) {
                return getBusinessErrorResponseVO(new BusinessException("权限不足"), "加载数据失败");
            }
            PaginationResultVO<AnnouncementsVo> resultVO = checkTableService.getApproveList(pageNum, pageSize);

            return getSuccessResponseVO(resultVO);
        } catch (BusinessException e) {
            return getBusinessErrorResponseVO(e, "加载数据失败");
        }
    }

    // 审批公告
    @PostMapping("/approveAnnouncement")
    public ResponseVO approveAnnouncement(HttpServletRequest request,
                                          @NotEmpty String announcementId,
                                          @NotEmpty Integer status) {
        try {
            TokenUserInfoDto tokenUserInfo = getTokenUserInfo(request);
            String userId = tokenUserInfo.getUserId();
            UserInfo userInfo = userInfoService.getUserInfoByUserId(userId);
            if (userInfo == null) {
                return getBusinessErrorResponseVO(new BusinessException("用户不存在"), "用户不存在");
            }
            Integer Role = userInfo.getRole();

            if (!Role.equals(UserRoleEnum.ADMIN.getType())) {
                return getBusinessErrorResponseVO(new BusinessException("权限不足"), "审批失败");
            }
            CheckTableQuery query = new CheckTableQuery();
            query.setAnnouncementId(announcementId);
            List<CheckTable> listByParam = checkTableService.findListByParam(query);
            CheckTable checkTable = listByParam.get(0);
            String checkId = checkTable.getCheckId();
            if (status == 1 || status == 2) {
                CheckTableVo checkTableVo = checkTableService.approveAnnouncement(checkId, status);

                return getSuccessResponseVO(checkTableVo);
            } else {
                return getBusinessErrorResponseVO(new BusinessException("status参数错误"), "审批失败");
            }
        } catch (BusinessException e) {
            return getBusinessErrorResponseVO(e, "审批失败");
        }
    }

    /**
     * 根据AnnouncementId删除
     */
    @RequestMapping("/deleteAnnouncementsByAnnouncementId")
    public ResponseVO deleteAnnouncementsByAnnouncementId(HttpServletRequest request,
                                                          @NotEmpty String announcementId) {
        try {
            String userId = getTokenUserInfo(request).getUserId();
            UserInfo userInfo = userInfoService.getUserInfoByUserId(userId);
            if (userInfo == null) {
                return getBusinessErrorResponseVO(new BusinessException("用户不存在"), "用户不存在");
            }
            if (!userInfo.getRole().equals(UserRoleEnum.ADMIN.getType())) {
                return getBusinessErrorResponseVO(new BusinessException("权限不足"), "删除文章失败");
            }
            announcementsService.deleteAnnouncementsByAnnouncementId(announcementId);
            return getSuccessResponseVO("删除成功");
        } catch (BusinessException e) {
            return getBusinessErrorResponseVO(e, "删除文章失败");
        }
    }
}
