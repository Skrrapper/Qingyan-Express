import axios from 'axios'

const adminApi = axios.create({
    baseURL: '/admin'
})

adminApi.interceptors.request.use(
    config => {
        const token =  localStorage.getItem('token') // get token
        if (token) {
            config.headers['token'] = token
        }
        return config
    },
    error => {
        return Promise.reject(error)
    }
)

export const approveAnnouncement = (announcementId, status) => {
    return adminApi.post('/approveAnnouncement', {
        announcementId,
        status
    })
}
