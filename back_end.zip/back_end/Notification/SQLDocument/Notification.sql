create schema Notification;

# 用户表---------------------------------------------------------------
create table user_info
(
    user_id             varchar(10)  not null comment '用户id',
    nick_name           varchar(20)  not null comment '昵称',
    email               varchar(150) not null comment '邮箱',
    password            varchar(32)  not null comment '密码',
    avatar              varchar(150) null comment '头像',
    sex                 tinyint(1)   null comment '0:女 1:男 2:未知',
    role                tinyint(1)   not null comment '0:管理员 1:学生 2:教师',
    create_time           datetime     not null comment '加入时间',
    status              tinyint(1)   not null comment '0:禁用 1:启用',
    constraint user_info_pk
        primary key (user_id)
);

create unique index user_email
    on user_info (email);

create unique index user_nick_name
    on user_info (nick_name);

# 邮箱验证码表------------------------------------------------------------
create table email_code
(
    email      varchar(150) not null comment '邮箱',
    creat_time datetime     null comment '验证码创建时间',
    code       varchar(5)   not null comment '邮箱编号',
    status     tinyint(1)   null comment '0:未使用 1:已使用'
);

create unique index email_code
    on email_code (code, email);

# 公告表-----------------------------------------------------------------
create table announcements
(
    announcement_id varchar(10)          not null comment '公告id',
    title           varchar(200)         not null comment '公告标题',
    content         text                 not null comment '公告内容',
    user_id         varchar(10)          not null comment '作者id',
    status          tinyint(1) default 0 not null comment '状态(0:草稿 1:发布 2:删除)',
    view_count      int        default 0 not null comment '浏览量',
    top             tinyint(1) default 0 not null comment '是否置顶(0:否 1:是)',
    create_time     datetime             null comment '创建时间',
    publish_time    datetime             null comment '发布时间',
    constraint announcements_pk
        primary key (announcement_id)
)
    comment '公告表';

# 评论表------------------------------------------------------------------
create table comments
(
    comment_id      varchar(10)          not null comment '评论id',
    announcement_id varchar(10)          not null comment '公告id',
    user_id         varchar(10)          not null comment '作者id',
    content         text                 not null comment '评论内容',
    status          tinyint(1) default 0 not null comment '状态(0:正常 1:删除)',
    create_time     datetime             null comment '创建时间',
    constraint comments_pk
        primary key (comment_id)
)
    comment '评论表';

# 审核表------------------------------------------------------------------
create table check_table(
    check_id        varchar(10)          not null comment '审核id',
    announcement_id varchar(10)          not null comment '公告id',
    user_id         varchar(10)          not null comment '审核人id',
    status          tinyint(1) default 0 not null comment '状态(0:待审核 1:通过 2:拒绝)',
    create_time     datetime             null comment '创建时间',
    constraint check_table_pk
        primary key (check_id)
) comment '审核表';


ALTER DATABASE Notification CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

ALTER TABLE user_info CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

ALTER TABLE announcements CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

ALTER TABLE comments CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

ALTER TABLE check_table CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
