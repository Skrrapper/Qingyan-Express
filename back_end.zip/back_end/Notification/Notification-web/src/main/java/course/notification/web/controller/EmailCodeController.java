package course.notification.web.controller;

import course.notification.service.EmailCodeService;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 *  Controller
 */
@RestController("emailCodeController")
@RequestMapping("/emailCode")
public class EmailCodeController extends ABaseController{

}