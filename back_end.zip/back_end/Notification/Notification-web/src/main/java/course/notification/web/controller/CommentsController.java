package course.notification.web.controller;

import course.notification.entity.constants.Constants;
import course.notification.entity.po.Comments;
import course.notification.entity.po.UserInfo;
import course.notification.entity.query.CommentsQuery;
import course.notification.entity.vo.CommentsVo;
import course.notification.entity.vo.ResponseVO;
import course.notification.exception.BusinessException;
import course.notification.service.AnnouncementsService;
import course.notification.service.CommentsService;
import course.notification.service.UserInfoService;
import course.notification.utils.CopyTools;
import course.notification.utils.StringTools;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.validation.constraints.NotEmpty;
import java.util.ArrayList;
import java.util.List;

/**
 * 评论表 Controller
 */
@RestController("commentsController")
@RequestMapping("/comments")
public class CommentsController extends ABaseController {
    @Resource
    private CommentsService commentsService;

    @Resource
    private UserInfoService userInfoService;

    @Resource
    private AnnouncementsService announcementsService;

    @PostMapping("/addComments")
    public ResponseVO addComments(HttpServletRequest request,
                                  @NotEmpty String announcementId,
                                  @NotEmpty String content) {
        try {
            String userId = getTokenUserInfo(request).getUserId();
            commentsService.addComments(userId, announcementId, content);
            return getSuccessResponseVO("评论成功");
        } catch (BusinessException e) {
            return getBusinessErrorResponseVO(e, null);
        }
    }

    // 获取评论列表
    @GetMapping("/getCommentsList")
    public ResponseVO getCommentsList(HttpServletRequest request,
                                      @NotEmpty CommentsQuery query) {
        try {
            query.setStatus(Constants.ZERO);
            List<Comments> listByParam = commentsService.findListByParam(query);

            List<CommentsVo> list = new ArrayList<>();
            for (Comments comments : listByParam) {
                CommentsVo commentsVo = new CommentsVo();
                CopyTools.copyProperties(comments, commentsVo);
                UserInfo userInfo = userInfoService.getUserInfoByUserId(comments.getUserId());
                commentsVo.setNickName(userInfo.getNickName());
                commentsVo.setAvatar(userInfo.getAvatar());
                list.add(commentsVo);
            }

            return getSuccessResponseVO(list);
        } catch (BusinessException e) {
            return getBusinessErrorResponseVO(e, null);
        }
    }

    // 删除评论
    @DeleteMapping("/deleteComments")
    public ResponseVO deleteComments(HttpServletRequest request,
                                     @NotEmpty String commentId) {
        try {
            String userId = getTokenUserInfo(request).getUserId();
            Comments comments = commentsService.getCommentsByCommentId(commentId);

            // 判断是否为本人评论或文章作者
            boolean isOwner = userId.equals(comments.getUserId());
            boolean isAnnouncementAuthor = false;

            if (!isOwner) {
                // 获取公告信息判断是否为文章作者
                String announcementId = comments.getAnnouncementId();
                // 需要注入 AnnouncementService 或相应服务来获取公告信息
                String uid = announcementsService.getAnnouncementsByAnnouncementId(announcementId).getUserId();
                isAnnouncementAuthor = uid.equals(userId);
                if (!isAnnouncementAuthor) {
                    return getServerErrorResponseVO("无权限删除");
                }
            }

            // 检查删除条件：是本人或文章作者，且status为1
            if ((isOwner || isAnnouncementAuthor) && comments.getStatus() == Constants.ZERO) {
                commentsService.deleteCommentsByCommentId(commentId);
                return getSuccessResponseVO("删除成功");
            } else {
                return getServerErrorResponseVO("无权限删除或评论状态不正确");
            }
        } catch (BusinessException e) {
            return getBusinessErrorResponseVO(e, null);
        }
    }

}