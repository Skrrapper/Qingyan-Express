package course.notification.web.controller;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import com.wf.captcha.ArithmeticCaptcha;
import course.notification.component.RedisComponent;
import course.notification.entity.config.AppConfig;
import course.notification.entity.constants.Constants;
import course.notification.entity.dto.TokenUserInfoDto;
import course.notification.entity.po.UserInfo;
import course.notification.entity.vo.ResponseVO;
import course.notification.exception.BusinessException;
import course.notification.service.EmailCodeService;
import course.notification.service.UserInfoService;
import course.notification.utils.StringTools;
import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

/**
 * 用户信息控制器
 */
@RestController("userInfoController")
@RequestMapping("/userInfo")
public class UserInfoController extends ABaseController {
    private static final Logger logger = LoggerFactory.getLogger(UserInfoController.class);

    @Autowired
    private RedisComponent redisComponent;

    @Autowired
    private UserInfoService userInfoService;

    @Resource
    private EmailCodeService emailCodeService;

    @Resource
    private AppConfig appConfig;

    // 获取图片验证码
    @GetMapping("/checkCode")
    public ResponseVO checkCode() {
        ArithmeticCaptcha captcha = new ArithmeticCaptcha(110, 40);
        String code = captcha.text();
        String checkCodeKey = redisComponent.saveCheckCode(code);
        String checkCodeBase64 = captcha.toBase64();

        Map<String, String> result = new HashMap<>();
        result.put("checkCode", checkCodeBase64);
        result.put("checkCodeKey", checkCodeKey);
        return getSuccessResponseVO(result);
    }

    // 发送邮箱验证码
    @PostMapping("/sendEmailCode")
    public ResponseVO sendEmailCode(@NotEmpty @Email String email) {
        try {
            emailCodeService.sendEmailCode(email);
            return getSuccessResponseVO("发送邮件成功");
        } catch (BusinessException e) {
            return getBusinessErrorResponseVO(e, "发送邮件失败");
        }
    }

    // 注册
    @PostMapping("/register")
    public ResponseVO register(@NotEmpty @Email @Size(max = 150) String email,
                               @NotEmpty @Size(max = 20) String nickName,
                               @NotEmpty @Pattern(regexp = Constants.REGEX_PASSWORD) String registerPassword,
                               @NotEmpty String checkCode,
                               @NotEmpty String checkCodeKey) {
        try {
            if (!checkCode.equalsIgnoreCase(redisComponent.getCheckCode(checkCodeKey))) {
                throw new BusinessException("图片验证码错误");
            }
            userInfoService.register(email, nickName, registerPassword);
            return getSuccessResponseVO(null);
        } finally {
            redisComponent.cleanCheckCode(checkCodeKey);
        }
    }

    // 登录
    @PostMapping("/login")
    public ResponseVO login(HttpServletResponse response,
                            @NotEmpty @Email String email,
                            @NotEmpty String password,
                            @NotEmpty String checkCode,
                            @NotEmpty String checkCodeKey) {
        try {
            if (!checkCode.equalsIgnoreCase(redisComponent.getCheckCode(checkCodeKey))) {
                throw new BusinessException("图片验证码错误");
            }
            TokenUserInfoDto tokenUserInfoDto = userInfoService.login(email, password);
            saveToken2Cookie(response, tokenUserInfoDto.getToken());

            return getSuccessResponseVO(tokenUserInfoDto);
        } finally {
            redisComponent.cleanCheckCode(checkCodeKey);
        }
    }

    // 邮箱登录
    @PostMapping("EmailLogin")
    public ResponseVO EmailLogin(HttpServletResponse response,
                                 @NotEmpty @Email String email,
                                 @NotEmpty String emailCode,
                                 @NotEmpty String checkCode,
                                 @NotEmpty String checkCodeKey) {
        try {
            if (!checkCode.equalsIgnoreCase(redisComponent.getCheckCode(checkCodeKey))) {
                throw new BusinessException("图片验证码错误");
            }
            TokenUserInfoDto tokenUserInfoDto = userInfoService.EmailLogin(email, emailCode);

            saveToken2Cookie(response, tokenUserInfoDto.getToken());

            return getSuccessResponseVO(tokenUserInfoDto);
        } finally {
            redisComponent.cleanCheckCode(checkCodeKey);
        }
    }


    // 退出登录
    @GetMapping("/logout")
    public ResponseVO logout(HttpServletResponse response) {
        cleanCookie(response);
        return getSuccessResponseVO(null);
    }

    // 登录前无token重置密码
    @PutMapping("/resetPwd")
    public ResponseVO resetPwd(@NotEmpty @Email String email,
                               @NotEmpty String password,
                               @NotEmpty String emailCode,
                               @NotEmpty String checkCode,
                               @NotEmpty String checkCodeKey) {
        try {
            // 验证图片验证码是否匹配（忽略大小写）
            if (!checkCode.equalsIgnoreCase(redisComponent.getCheckCode(checkCodeKey))) {
                throw new BusinessException("图片验证码错误");
            }
            // 调用服务层执行密码重置操作（包含邮箱验证码校验）
            userInfoService.resetPwd(email, password, emailCode);

            // 返回成功响应
            return getSuccessResponseVO(null);
        } finally {
            // 最终清理会话中的图片验证码（无论成功或异常）
            redisComponent.cleanCheckCode(checkCodeKey);
        }
    }

    // 登录后有token更新密码
    @PutMapping("/updatePassword")
    public ResponseVO updatePassword(HttpServletRequest request,
                                     @NotEmpty String newPassword) {
        // 从会话中获取完整的用户认证信息
        TokenUserInfoDto tokenUserInfoDto = getTokenUserInfo(request);
        // 构建用户信息更新对象并加密存储密码
        UserInfo userInfo = new UserInfo();
        userInfo.setPassword(StringTools.encodeByMD5(newPassword));
        // 根据用户ID执行数据库更新操作
        userInfoService.updateUserInfoByUserId(userInfo, tokenUserInfoDto.getUserId());
        // 返回操作成功响应（无具体数据返回）
        return getSuccessResponseVO(null);
    }

    // 上传头像接口
    @PutMapping("/uploadAvatar")
    public ResponseVO uploadAvatar(HttpServletRequest request,
                                   @RequestParam("file") MultipartFile file) { // 通过参数或token获取userId更安全
        try {
            // 从会话中获取完整的用户认证信息
            TokenUserInfoDto tokenUserInfoDto = getTokenUserInfo(request);
            String userId = tokenUserInfoDto.getUserId();
            String avatarPath = userInfoService.uploadAvatar(file, userId);
            return getSuccessResponseVO(avatarPath);
        } catch (BusinessException e) {
            return getBusinessErrorResponseVO(e, "头像上传失败");
        }
    }

    // 获取自己头像接口
    @GetMapping("/getAvatar")
    public void getAvatar(HttpServletRequest request,
                          HttpServletResponse response) {
        try {
            String userId = getTokenUserInfo(request).getUserId();
            String avatarPath = userInfoService.getAvatar(userId);
            logger.info("文件路径为：{}", avatarPath);
            if (StringTools.isEmpty(avatarPath)) {
                // 返回默认头像或404
                return;
            }
            File file = new File(avatarPath);
            FileUtils.copyFile(file, response.getOutputStream());
            response.setContentType("image/jpeg");
        } catch (IOException e) {
            logger.error("获取头像失败", e);
        }
    }

    @GetMapping("/getUserAvatar")
    public void getUserAvatar(@NotEmpty String userId,
                              HttpServletResponse response) {
        try {
            String avatarPath = userInfoService.getAvatar(userId);
            logger.info("文件路径为：{}", avatarPath);
            if (StringTools.isEmpty(avatarPath)) {
                avatarPath = appConfig.getProjectFolder() + "/static/avatars/" + "default_avatar.jpg";
                logger.info("文件路径为：{}", avatarPath);
            }
            File file = new File(avatarPath);
            FileUtils.copyFile(file, response.getOutputStream());
            response.setContentType("image/jpeg");
        } catch (IOException e) {
            logger.error("获取头像失败", e);
        }
    }
}