package course.notification.web.controller;

import course.notification.entity.dto.AnnouncementDto;
import course.notification.entity.dto.TokenUserInfoDto;
import course.notification.entity.po.Announcements;
import course.notification.entity.query.AnnouncementsQuery;
import course.notification.entity.vo.AnnouncementsDetailVo;
import course.notification.entity.vo.AnnouncementsVo;
import course.notification.entity.vo.PaginationResultVO;
import course.notification.entity.vo.ResponseVO;
import course.notification.exception.BusinessException;
import course.notification.service.AnnouncementsService;
import course.notification.service.impl.UserInfoServiceImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.validation.constraints.NotEmpty;

/**
 * 公告表 Controller
 */
@RestController("announcementsController")
@RequestMapping("/announcements")
public class AnnouncementsController extends ABaseController {
    private static final Logger logger = LoggerFactory.getLogger(UserInfoController.class);

    @Resource
    private AnnouncementsService announcementsService;
    @Autowired
    private UserInfoServiceImpl userInfoService;

    // 编辑公告（草稿）
    @PostMapping("/addAnnouncement")
    public ResponseVO addAnnouncement(HttpServletRequest request,
                                      @NotEmpty String title,
                                      @NotEmpty String content
    ) {
        try {
            TokenUserInfoDto tokenUserInfoDto = getTokenUserInfo(request);
            if (tokenUserInfoDto == null) {
                return getBusinessErrorResponseVO(new BusinessException("用户未登录"), "用户未登录");
            }
            String userId = tokenUserInfoDto.getUserId();
            logger.info("用户ID为：{}，标题为：{}，内容为：{}", userId, title, content);

            AnnouncementDto announcementDto = announcementsService.addAnnouncement(userId, title, content);

            return getSuccessResponseVO(announcementDto);
        } catch (BusinessException e) {
            return getBusinessErrorResponseVO(e, "编辑文本失败");
        }
    }

    // 发布公告
    @PutMapping("/publishAnnouncement")
    public ResponseVO publishAnnouncement(HttpServletRequest request,
                                          @NotEmpty String announcementId
    ) {
        try {
            TokenUserInfoDto tokenUserInfoDto = getTokenUserInfo(request);
            String userId = tokenUserInfoDto.getUserId();

            AnnouncementDto announcementDto = announcementsService.publishAnnouncement(userId, announcementId);

            return getSuccessResponseVO("发布成功");
        } catch (BusinessException e) {
            return getBusinessErrorResponseVO(e, "发布失败");
        }
    }

    // 删除公告
    @DeleteMapping("/deleteAnnouncement")
    public ResponseVO deleteAnnouncement(HttpServletRequest request,
                                         @NotEmpty String announcementId) {
        try {
            TokenUserInfoDto tokenUserInfoDto = getTokenUserInfo(request);
            String userId = tokenUserInfoDto.getUserId();

            AnnouncementDto announcementDto = announcementsService.deleteAnnouncement(userId, announcementId);

            return getSuccessResponseVO("删除成功");
        } catch (BusinessException e) {
            return getBusinessErrorResponseVO(e, "删除失败");
        }
    }

    // 修改公告内容
    @PutMapping("/updateAnnouncement")
    public ResponseVO updateAnnouncement(HttpServletRequest request,
                                         @NotEmpty String announcementId,
                                         @NotEmpty String title,
                                         @NotEmpty String content) {
        try {
            TokenUserInfoDto tokenUserInfoDto = getTokenUserInfo(request);
            String userId = tokenUserInfoDto.getUserId();

            AnnouncementDto announcementDto = announcementsService.updateAnnouncement(userId, announcementId, title, content);

            return getSuccessResponseVO("修改成功");
        } catch (BusinessException e) {
            return getBusinessErrorResponseVO(e, "修改失败");
        }
    }

    // 获取公告列表（日期排序）
    @GetMapping("/getAnnouncementListByDate")
    public ResponseVO getAnnouncementListByDate(HttpServletRequest request,
                                                @NotEmpty Integer pageNum,
                                                @NotEmpty Integer pageSize,
                                                @NotEmpty Integer way) {
        try {
            if (pageNum < 1 || pageSize < 1) {
                return getBusinessErrorResponseVO(new BusinessException("参数错误"), "页码和每页数量不能小于1");
            }

            PaginationResultVO<AnnouncementsVo> announcementList = announcementsService.getAnnouncementListByDate(pageNum, pageSize, way);

            return getSuccessResponseVO(announcementList);
        } catch (BusinessException e) {
            return getBusinessErrorResponseVO(e, "获取失败");
        }
    }

    // 获取公告列表（浏览量排序）
    @GetMapping("/getAnnouncementListByViewCount")
    public ResponseVO getAnnouncementListByViewCount(HttpServletRequest request,
                                                     @NotEmpty Integer pageNum,
                                                     @NotEmpty Integer pageSize,
                                                     @NotEmpty Integer way) {
        try {

            if (pageNum < 1 || pageSize < 1) {
                return getBusinessErrorResponseVO(new BusinessException("参数错误"), "页码和每页数量不能小于1");
            }

            PaginationResultVO<AnnouncementsVo> announcementList = announcementsService.getAnnouncementListByViewCount(pageNum, pageSize, way);

            return getSuccessResponseVO(announcementList);
        } catch (BusinessException e) {
            return getBusinessErrorResponseVO(e, "获取失败");
        }

    }

    // 浏览公告
    @GetMapping("/viewAnnouncement")
    public ResponseVO viewAnnouncement(HttpServletRequest request,
                                       @NotEmpty String announcementId) {
        try {
            Announcements announcement = announcementsService.getAnnouncementsByAnnouncementId(announcementId);
            if (announcement == null) {
                return getBusinessErrorResponseVO(new BusinessException("公告不存在"), "公告不存在");
            }

            // 浏览量+1
            AnnouncementsDetailVo announcementDetailVo = announcementsService.viewAnnouncement(announcementId);

            return getSuccessResponseVO(announcementDetailVo);
        } catch (BusinessException e) {
            return getBusinessErrorResponseVO(e, "浏览失败");
        }
    }

    // 作者加载自己所有的公告
    @GetMapping("/loadDataList")
    public ResponseVO loadDataList(HttpServletRequest request,
                                   AnnouncementsQuery query,
                                   Integer pageNum,
                                   Integer pageSize) {
        try {
            TokenUserInfoDto tokenUserInfoDto = getTokenUserInfo(request);
            String userId = tokenUserInfoDto.getUserId();

            PaginationResultVO<AnnouncementsVo> announcementList = announcementsService.loadDataList(userId, query, pageNum, pageSize);
            return getSuccessResponseVO(announcementList);
        } catch (Exception e) {
            return getServerErrorResponseVO("获取失败");
        }
    }

    // 搜索公告
    @GetMapping("/searchAnnouncement")
    public ResponseVO searchAnnouncement(HttpServletRequest request,
                                         AnnouncementsQuery query,
                                         Integer pageNum,
                                         Integer pageSize) {
        try {
            PaginationResultVO<AnnouncementsVo> announcementList = announcementsService.searchAnnouncement(query, pageNum, pageSize);
            return getSuccessResponseVO(announcementList);
        } catch (Exception e) {
            return getServerErrorResponseVO("获取失败");
        }
    }
}