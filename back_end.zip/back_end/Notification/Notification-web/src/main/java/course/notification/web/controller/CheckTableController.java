package course.notification.web.controller;

import java.util.List;

import course.notification.entity.query.CheckTableQuery;
import course.notification.entity.po.CheckTable;
import course.notification.entity.vo.ResponseVO;
import course.notification.service.CheckTableService;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * 审核表 Controller
 */
@RestController("checkTableController")
@RequestMapping("/checkTable")
public class CheckTableController extends ABaseController{

}