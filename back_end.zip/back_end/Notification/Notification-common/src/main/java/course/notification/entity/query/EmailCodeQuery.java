package course.notification.entity.query;

import java.util.Date;


/**
 * 参数
 */
public class EmailCodeQuery extends BaseParam {


	/**
	 * 邮箱
	 */
	private String email;

	private String emailFuzzy;

	/**
	 * 验证码创建时间
	 */
	private String creatTime;

	private String creatTimeStart;

	private String creatTimeEnd;

	/**
	 * 邮箱编号
	 */
	private String code;

	private String codeFuzzy;

	/**
	 * 0:未使用 1:已使用
	 */
	private Integer status;


	public void setEmail(String email){
		this.email = email;
	}

	public String getEmail(){
		return this.email;
	}

	public void setEmailFuzzy(String emailFuzzy){
		this.emailFuzzy = emailFuzzy;
	}

	public String getEmailFuzzy(){
		return this.emailFuzzy;
	}

	public void setCreatTime(String creatTime){
		this.creatTime = creatTime;
	}

	public String getCreatTime(){
		return this.creatTime;
	}

	public void setCreatTimeStart(String creatTimeStart){
		this.creatTimeStart = creatTimeStart;
	}

	public String getCreatTimeStart(){
		return this.creatTimeStart;
	}
	public void setCreatTimeEnd(String creatTimeEnd){
		this.creatTimeEnd = creatTimeEnd;
	}

	public String getCreatTimeEnd(){
		return this.creatTimeEnd;
	}

	public void setCode(String code){
		this.code = code;
	}

	public String getCode(){
		return this.code;
	}

	public void setCodeFuzzy(String codeFuzzy){
		this.codeFuzzy = codeFuzzy;
	}

	public String getCodeFuzzy(){
		return this.codeFuzzy;
	}

	public void setStatus(Integer status){
		this.status = status;
	}

	public Integer getStatus(){
		return this.status;
	}

}
