package course.notification.entity.po;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.util.Date;
import course.notification.entity.enums.DateTimePatternEnum;
import course.notification.utils.DateUtil;
import com.fasterxml.jackson.annotation.JsonFormat;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;


/**
 * 评论表
 */
public class Comments implements Serializable {


	/**
	 * 评论id
	 */
	private String commentId;

	/**
	 * 公告id
	 */
	private String announcementId;

	/**
	 * 作者id
	 */
	private String userId;

	/**
	 * 评论内容
	 */
	private String content;

	/**
	 * 状态(0:正常 1:删除)
	 */
	private Integer status;

	/**
	 * 创建时间
	 */
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date createTime;


	public void setCommentId(String commentId){
		this.commentId = commentId;
	}

	public String getCommentId(){
		return this.commentId;
	}

	public void setAnnouncementId(String announcementId){
		this.announcementId = announcementId;
	}

	public String getAnnouncementId(){
		return this.announcementId;
	}

	public void setUserId(String userId){
		this.userId = userId;
	}

	public String getUserId(){
		return this.userId;
	}

	public void setContent(String content){
		this.content = content;
	}

	public String getContent(){
		return this.content;
	}

	public void setStatus(Integer status){
		this.status = status;
	}

	public Integer getStatus(){
		return this.status;
	}

	public void setCreateTime(Date createTime){
		this.createTime = createTime;
	}

	public Date getCreateTime(){
		return this.createTime;
	}

	@Override
	public String toString (){
		return "评论id:"+(commentId == null ? "空" : commentId)+"，公告id:"+(announcementId == null ? "空" : announcementId)+"，作者id:"+(userId == null ? "空" : userId)+"，评论内容:"+(content == null ? "空" : content)+"，状态(0:正常 1:删除):"+(status == null ? "空" : status)+"，创建时间:"+(createTime == null ? "空" : DateUtil.format(createTime, DateTimePatternEnum.YYYY_MM_DD_HH_MM_SS.getPattern()));
	}
}
