package course.notification.entity.constants;

public class Constants {

    public static final Integer ZERO = 0;
    public static final Integer ONE = 1;
    public static final Integer TWO = 2;
    public static final Integer LENGTH_5 = 5;
    public static final Integer LENGTH_9 = 9;
    public static final Integer LENGTH_10 = 10;
    public static final Integer LENGTH_15 = 15;

    // 密码正则
    public static final String REGEX_PASSWORD = "^(?=.*[0-9a-zA-Z@#$%^&+=])(?=\\S+$).{8,18}$";

    // 文件上传路径
    public static final String FILE_FOLDER_FILE = "/file/";
    public static final String FILE_FOLDER_AVATAR = "avatar/";
    public static final String AVATAR_SUFFIX = ".jpg";
    public static final String AVATAR_DEFAULT = "default_avatar.jpg";

    // 验证码过期时间
    public static final Integer REDIS_KEY_EXPIRES_ONE_MIN= 60000;
    public static final Integer REDIS_KEY_EXPIRES_ONE_DAY= REDIS_KEY_EXPIRES_ONE_MIN*60*24;
    public static final Integer TIME_SECONDS_DAY= REDIS_KEY_EXPIRES_ONE_DAY/1000;

    // redis key前缀
    public static final String REDIS_KEY_PREFIX = "Notification:";

    // 验证码key
    public static final String REDIS_KEY_CHECK_CODE = REDIS_KEY_PREFIX + "checkCode:";
    public static final String CHECK_CODE_KEY = "check_code_key";
    public static final String SESSION_KEY = "session_key";

    // token key
    public static final String REDIS_KEY_TOKEN_WEB = REDIS_KEY_PREFIX + "token:web:";
    public static final String REDIS_KEY_TOKEN_ADMIN = REDIS_KEY_PREFIX + "token:admin:";

    public static final String TOKEN_WEB = "Token-Web";
    public static final String TOKEN_ADMIN = "Token-Admin";
}
