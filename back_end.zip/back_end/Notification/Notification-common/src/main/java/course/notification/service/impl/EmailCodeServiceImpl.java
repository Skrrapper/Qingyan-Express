package course.notification.service.impl;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.mail.internet.MimeMessage;

import course.notification.component.RedisComponent;
import course.notification.entity.config.EmailConfig;
import course.notification.entity.constants.Constants;
import course.notification.exception.BusinessException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import course.notification.entity.enums.PageSize;
import course.notification.entity.query.EmailCodeQuery;
import course.notification.entity.po.EmailCode;
import course.notification.entity.vo.PaginationResultVO;
import course.notification.entity.query.SimplePage;
import course.notification.mappers.EmailCodeMapper;
import course.notification.service.EmailCodeService;
import course.notification.utils.StringTools;
import org.springframework.transaction.annotation.Transactional;


/**
 *  业务接口实现
 */
@Service("emailCodeService")
public class EmailCodeServiceImpl implements EmailCodeService {

	private static final Logger logger = LoggerFactory.getLogger(EmailCodeServiceImpl.class);

	@Resource
	private EmailCodeMapper<EmailCode, EmailCodeQuery> emailCodeMapper;

	@Resource
	private JavaMailSender javaMailSender;

	@Resource
	private EmailConfig emailConfig;

	/**
	 * 根据条件查询列表
	 */
	@Override
	public List<EmailCode> findListByParam(EmailCodeQuery param) {
		return this.emailCodeMapper.selectList(param);
	}

	/**
	 * 根据条件查询列表
	 */
	@Override
	public Integer findCountByParam(EmailCodeQuery param) {
		return this.emailCodeMapper.selectCount(param);
	}

	/**
	 * 分页查询方法
	 */
	@Override
	public PaginationResultVO<EmailCode> findListByPage(EmailCodeQuery param) {
		int count = this.findCountByParam(param);
		int pageSize = param.getPageSize() == null ? PageSize.SIZE15.getSize() : param.getPageSize();

		SimplePage page = new SimplePage(param.getPageNo(), count, pageSize);
		param.setSimplePage(page);
		List<EmailCode> list = this.findListByParam(param);
		PaginationResultVO<EmailCode> result = new PaginationResultVO(count, page.getPageSize(), page.getPageNo(), page.getPageTotal(), list);
		return result;
	}

	/**
	 * 新增
	 */
	@Override
	public Integer add(EmailCode bean) {
		return this.emailCodeMapper.insert(bean);
	}

	/**
	 * 批量新增
	 */
	@Override
	public Integer addBatch(List<EmailCode> listBean) {
		if (listBean == null || listBean.isEmpty()) {
			return 0;
		}
		return this.emailCodeMapper.insertBatch(listBean);
	}

	/**
	 * 批量新增或者修改
	 */
	@Override
	public Integer addOrUpdateBatch(List<EmailCode> listBean) {
		if (listBean == null || listBean.isEmpty()) {
			return 0;
		}
		return this.emailCodeMapper.insertOrUpdateBatch(listBean);
	}

	/**
	 * 多条件更新
	 */
	@Override
	public Integer updateByParam(EmailCode bean, EmailCodeQuery param) {
		StringTools.checkParam(param);
		return this.emailCodeMapper.updateByParam(bean, param);
	}

	/**
	 * 多条件删除
	 */
	@Override
	public Integer deleteByParam(EmailCodeQuery param) {
		StringTools.checkParam(param);
		return this.emailCodeMapper.deleteByParam(param);
	}

	/**
	 * 根据CodeAndEmail获取对象
	 */
	@Override
	public EmailCode getEmailCodeByCodeAndEmail(String code, String email) {
		return this.emailCodeMapper.selectByCodeAndEmail(code, email);
	}

	/**
	 * 根据CodeAndEmail修改
	 */
	@Override
	public Integer updateEmailCodeByCodeAndEmail(EmailCode bean, String code, String email) {
		return this.emailCodeMapper.updateByCodeAndEmail(bean, code, email);
	}

	/**
	 * 根据CodeAndEmail删除
	 */
	@Override
	public Integer deleteEmailCodeByCodeAndEmail(String code, String email) {
		return this.emailCodeMapper.deleteByCodeAndEmail(code, email);
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public void sendEmailCode(String email) {
		String code = StringTools.getRandomNumber(Constants.LENGTH_5);
		emailCodeMapper.disableByEmail(email);

		//TODO 发送验证码
		sentMailCode(email, code);

		EmailCode emailCode = new EmailCode();
		emailCode.setCode(code);
		emailCode.setEmail(email);
		emailCode.setStatus(Constants.ZERO);
		emailCode.setCreatTime(new Date());
		emailCodeMapper.insert(emailCode);
	}

	@Override
	public void checkCode(String email, String code) {
		EmailCode emailCode = this.emailCodeMapper.selectByCodeAndEmail(code, email);
		if(emailCode == null){
			throw new BusinessException("验证码错误");
		}
		if(emailCode.getStatus() == 1 || System.currentTimeMillis()-emailCode.getCreatTime().getTime() > Constants.LENGTH_10 * 1000 * 60){
			throw new BusinessException("验证码已失效");
		}

		emailCodeMapper.disableByEmail(email);
	}

	private void sentMailCode(String toEmail , String code){
		try{
			MimeMessage message = javaMailSender.createMimeMessage();
			MimeMessageHelper helper = new MimeMessageHelper(message, true);
			helper.setFrom(emailConfig.getSendUsername());
			helper.setTo(toEmail);

			helper.setSubject("青言速递 邮箱验证码");

			String htmlContent = new String(Files.readAllBytes(Paths.get("static/email/EmailHtml.html")), "UTF-8");
			htmlContent = htmlContent.replace("123456", code);
			helper.setText(htmlContent, true);

			javaMailSender.send(message);
		}catch(Exception e){
			logger.error("邮件发送失败", e);
			throw new BusinessException("邮件发送失败");
		}
	}
}