package course.notification.mappers;

import org.apache.ibatis.annotations.Param;

/**
 * 审核表 数据库操作接口
 */
public interface CheckTableMapper<T,P> extends BaseMapper<T,P> {

	/**
	 * 根据CheckId更新
	 */
	 Integer updateByCheckId(@Param("bean") T t,@Param("checkId") String checkId);


	/**
	 * 根据CheckId删除
	 */
	 Integer deleteByCheckId(@Param("checkId") String checkId);


	/**
	 * 根据CheckId获取对象
	 */
	 T selectByCheckId(@Param("checkId") String checkId);


}
