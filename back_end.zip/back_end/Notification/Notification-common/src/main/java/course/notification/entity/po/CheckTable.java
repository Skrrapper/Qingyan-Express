package course.notification.entity.po;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.util.Date;
import course.notification.entity.enums.DateTimePatternEnum;
import course.notification.utils.DateUtil;
import com.fasterxml.jackson.annotation.JsonFormat;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;


/**
 * 审核表
 */
public class CheckTable implements Serializable {


	/**
	 * 审核id
	 */
	private String checkId;

	/**
	 * 公告id
	 */
	private String announcementId;

	/**
	 * 审核人id
	 */
	private String userId;

	/**
	 * 状态(0:待审核 1:通过 2:拒绝)
	 */
	private Integer status;

	/**
	 * 创建时间
	 */
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date createTime;


	public void setCheckId(String checkId){
		this.checkId = checkId;
	}

	public String getCheckId(){
		return this.checkId;
	}

	public void setAnnouncementId(String announcementId){
		this.announcementId = announcementId;
	}

	public String getAnnouncementId(){
		return this.announcementId;
	}

	public void setUserId(String userId){
		this.userId = userId;
	}

	public String getUserId(){
		return this.userId;
	}

	public void setStatus(Integer status){
		this.status = status;
	}

	public Integer getStatus(){
		return this.status;
	}

	public void setCreateTime(Date createTime){
		this.createTime = createTime;
	}

	public Date getCreateTime(){
		return this.createTime;
	}

	@Override
	public String toString (){
		return "审核id:"+(checkId == null ? "空" : checkId)+"，公告id:"+(announcementId == null ? "空" : announcementId)+"，审核人id:"+(userId == null ? "空" : userId)+"，状态(0:待审核 1:通过 2:拒绝):"+(status == null ? "空" : status)+"，创建时间:"+(createTime == null ? "空" : DateUtil.format(createTime, DateTimePatternEnum.YYYY_MM_DD_HH_MM_SS.getPattern()));
	}
}
