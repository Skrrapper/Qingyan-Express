package course.notification.entity.query;

import java.util.Date;


/**
 * 公告表参数
 */
public class AnnouncementsQuery extends BaseParam {


	/**
	 * 公告id
	 */
	private String announcementId;

	private String announcementIdFuzzy;

	/**
	 * 公告标题
	 */
	private String title;

	private String titleFuzzy;

	/**
	 * 公告内容
	 */
	private String content;

	private String contentFuzzy;

	/**
	 * 作者id
	 */
	private String userId;

	private String userIdFuzzy;

	/**
	 * 状态(0:草稿 1:发布 2:删除)
	 */
	private Integer status;

	/**
	 * 浏览量
	 */
	private Integer viewCount;

	/**
	 * 是否置顶(0:否 1:是)
	 */
	private Integer top;

	/**
	 * 创建时间
	 */
	private String createTime;

	private String createTimeStart;

	private String createTimeEnd;

	/**
	 * 发布时间
	 */
	private String publishTime;

	private String publishTimeStart;

	private String publishTimeEnd;


	public void setAnnouncementId(String announcementId){
		this.announcementId = announcementId;
	}

	public String getAnnouncementId(){
		return this.announcementId;
	}

	public void setAnnouncementIdFuzzy(String announcementIdFuzzy){
		this.announcementIdFuzzy = announcementIdFuzzy;
	}

	public String getAnnouncementIdFuzzy(){
		return this.announcementIdFuzzy;
	}

	public void setTitle(String title){
		this.title = title;
	}

	public String getTitle(){
		return this.title;
	}

	public void setTitleFuzzy(String titleFuzzy){
		this.titleFuzzy = titleFuzzy;
	}

	public String getTitleFuzzy(){
		return this.titleFuzzy;
	}

	public void setContent(String content){
		this.content = content;
	}

	public String getContent(){
		return this.content;
	}

	public void setContentFuzzy(String contentFuzzy){
		this.contentFuzzy = contentFuzzy;
	}

	public String getContentFuzzy(){
		return this.contentFuzzy;
	}

	public void setUserId(String userId){
		this.userId = userId;
	}

	public String getUserId(){
		return this.userId;
	}

	public void setUserIdFuzzy(String userIdFuzzy){
		this.userIdFuzzy = userIdFuzzy;
	}

	public String getUserIdFuzzy(){
		return this.userIdFuzzy;
	}

	public void setStatus(Integer status){
		this.status = status;
	}

	public Integer getStatus(){
		return this.status;
	}

	public void setViewCount(Integer viewCount){
		this.viewCount = viewCount;
	}

	public Integer getViewCount(){
		return this.viewCount;
	}

	public void setTop(Integer top){
		this.top = top;
	}

	public Integer getTop(){
		return this.top;
	}

	public void setCreateTime(String createTime){
		this.createTime = createTime;
	}

	public String getCreateTime(){
		return this.createTime;
	}

	public void setCreateTimeStart(String createTimeStart){
		this.createTimeStart = createTimeStart;
	}

	public String getCreateTimeStart(){
		return this.createTimeStart;
	}
	public void setCreateTimeEnd(String createTimeEnd){
		this.createTimeEnd = createTimeEnd;
	}

	public String getCreateTimeEnd(){
		return this.createTimeEnd;
	}

	public void setPublishTime(String publishTime){
		this.publishTime = publishTime;
	}

	public String getPublishTime(){
		return this.publishTime;
	}

	public void setPublishTimeStart(String publishTimeStart){
		this.publishTimeStart = publishTimeStart;
	}

	public String getPublishTimeStart(){
		return this.publishTimeStart;
	}
	public void setPublishTimeEnd(String publishTimeEnd){
		this.publishTimeEnd = publishTimeEnd;
	}

	public String getPublishTimeEnd(){
		return this.publishTimeEnd;
	}

}
