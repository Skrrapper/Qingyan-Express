package course.notification.service;

import java.util.List;

import course.notification.entity.query.CheckTableQuery;
import course.notification.entity.po.CheckTable;
import course.notification.entity.vo.AnnouncementsVo;
import course.notification.entity.vo.CheckTableVo;
import course.notification.entity.vo.PaginationResultVO;

import javax.servlet.http.HttpServletRequest;


/**
 * 审核表 业务接口
 */
public interface CheckTableService {

	/**
	 * 根据条件查询列表
	 */
	List<CheckTable> findListByParam(CheckTableQuery param);

	/**
	 * 根据条件查询列表
	 */
	Integer findCountByParam(CheckTableQuery param);

	/**
	 * 分页查询
	 */
	PaginationResultVO<CheckTable> findListByPage(CheckTableQuery param);

	/**
	 * 新增
	 */
	Integer add(CheckTable bean);

	/**
	 * 批量新增
	 */
	Integer addBatch(List<CheckTable> listBean);

	/**
	 * 批量新增/修改
	 */
	Integer addOrUpdateBatch(List<CheckTable> listBean);

	/**
	 * 多条件更新
	 */
	Integer updateByParam(CheckTable bean,CheckTableQuery param);

	/**
	 * 多条件删除
	 */
	Integer deleteByParam(CheckTableQuery param);

	/**
	 * 根据CheckId查询对象
	 */
	CheckTable getCheckTableByCheckId(String checkId);


	/**
	 * 根据CheckId修改
	 */
	Integer updateCheckTableByCheckId(CheckTable bean,String checkId);


	/**
	 * 根据CheckId删除
	 */
	Integer deleteCheckTableByCheckId(String checkId);

	CheckTableVo approveAnnouncement(String checkId, Integer status);

	PaginationResultVO<AnnouncementsVo> getApproveList(Integer pageNum, Integer pageSize);
}