package course.notification.entity.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("emailConfig")
public class EmailConfig {
    @Value("${spring.mail.username}")
    private String sendUsername;

    @Value("${project.folder:}")
    private String projectFolder;

    public String getSendUsername() {
        return sendUsername;
    }

    public String getProjectFolder() {
        return projectFolder;
    }
}

