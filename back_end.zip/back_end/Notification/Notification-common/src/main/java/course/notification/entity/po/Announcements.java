package course.notification.entity.po;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.util.Date;
import course.notification.entity.enums.DateTimePatternEnum;
import course.notification.utils.DateUtil;
import com.fasterxml.jackson.annotation.JsonFormat;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;


/**
 * 公告表
 */
public class Announcements implements Serializable {


	/**
	 * 公告id
	 */
	private String announcementId;

	/**
	 * 公告标题
	 */
	private String title;

	/**
	 * 公告内容
	 */
	private String content;

	/**
	 * 作者id
	 */
	private String userId;

	/**
	 * 状态(0:草稿 1:发布 2:删除)
	 */
	private Integer status;

	/**
	 * 浏览量
	 */
	private Integer viewCount;

	/**
	 * 是否置顶(0:否 1:是)
	 */
	private Integer top;

	/**
	 * 创建时间
	 */
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date createTime;

	/**
	 * 发布时间
	 */
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date publishTime;


	public void setAnnouncementId(String announcementId){
		this.announcementId = announcementId;
	}

	public String getAnnouncementId(){
		return this.announcementId;
	}

	public void setTitle(String title){
		this.title = title;
	}

	public String getTitle(){
		return this.title;
	}

	public void setContent(String content){
		this.content = content;
	}

	public String getContent(){
		return this.content;
	}

	public void setUserId(String userId){
		this.userId = userId;
	}

	public String getUserId(){
		return this.userId;
	}

	public void setStatus(Integer status){
		this.status = status;
	}

	public Integer getStatus(){
		return this.status;
	}

	public void setViewCount(Integer viewCount){
		this.viewCount = viewCount;
	}

	public Integer getViewCount(){
		return this.viewCount;
	}

	public void setTop(Integer top){
		this.top = top;
	}

	public Integer getTop(){
		return this.top;
	}

	public void setCreateTime(Date createTime){
		this.createTime = createTime;
	}

	public Date getCreateTime(){
		return this.createTime;
	}

	public void setPublishTime(Date publishTime){
		this.publishTime = publishTime;
	}

	public Date getPublishTime(){
		return this.publishTime;
	}

	@Override
	public String toString (){
		return "公告id:"+(announcementId == null ? "空" : announcementId)+"，公告标题:"+(title == null ? "空" : title)+"，公告内容:"+(content == null ? "空" : content)+"，作者id:"+(userId == null ? "空" : userId)+"，状态(0:草稿 1:发布 2:删除):"+(status == null ? "空" : status)+"，浏览量:"+(viewCount == null ? "空" : viewCount)+"，是否置顶(0:否 1:是):"+(top == null ? "空" : top)+"，创建时间:"+(createTime == null ? "空" : DateUtil.format(createTime, DateTimePatternEnum.YYYY_MM_DD_HH_MM_SS.getPattern()))+"，发布时间:"+(publishTime == null ? "空" : DateUtil.format(publishTime, DateTimePatternEnum.YYYY_MM_DD_HH_MM_SS.getPattern()));
	}
}
