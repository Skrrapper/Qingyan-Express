package course.notification.entity.enums;

/**
 * 用户角色枚举类
 */
public enum UserRoleEnum {

    ADMIN(0, "管理员"),
    STUDENT(1, "学生"),
    TEACHER(2, "教师");

    private Integer type;
    private String desc;

    UserRoleEnum(Integer type, String desc) {
        this.type = type;
        this.desc = desc;
    }

    /**
     * 根据类型获取枚举值
     *
     * @param type 类型值
     * @return 对应的枚举对象，找不到则返回 null
     */
    public static UserRoleEnum getEnumByType(Integer type) {
        for (UserRoleEnum userRoleEnum : UserRoleEnum.values()) {
            if (userRoleEnum.getType().equals(type)) {
                return userRoleEnum;
            }
        }
        return null;
    }

    public Integer getType() {
        return type;
    }

    public String getDesc() {
        return desc;
    }
}
