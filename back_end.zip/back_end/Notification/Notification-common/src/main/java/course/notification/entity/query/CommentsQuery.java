package course.notification.entity.query;

import java.util.Date;


/**
 * 评论表参数
 */
public class CommentsQuery extends BaseParam {


	/**
	 * 评论id
	 */
	private String commentId;

	private String commentIdFuzzy;

	/**
	 * 公告id
	 */
	private String announcementId;

	private String announcementIdFuzzy;

	/**
	 * 作者id
	 */
	private String userId;

	private String userIdFuzzy;

	/**
	 * 评论内容
	 */
	private String content;

	private String contentFuzzy;

	/**
	 * 状态(0:正常 1:删除)
	 */
	private Integer status;

	/**
	 * 创建时间
	 */
	private String createTime;

	private String createTimeStart;

	private String createTimeEnd;


	public void setCommentId(String commentId){
		this.commentId = commentId;
	}

	public String getCommentId(){
		return this.commentId;
	}

	public void setCommentIdFuzzy(String commentIdFuzzy){
		this.commentIdFuzzy = commentIdFuzzy;
	}

	public String getCommentIdFuzzy(){
		return this.commentIdFuzzy;
	}

	public void setAnnouncementId(String announcementId){
		this.announcementId = announcementId;
	}

	public String getAnnouncementId(){
		return this.announcementId;
	}

	public void setAnnouncementIdFuzzy(String announcementIdFuzzy){
		this.announcementIdFuzzy = announcementIdFuzzy;
	}

	public String getAnnouncementIdFuzzy(){
		return this.announcementIdFuzzy;
	}

	public void setUserId(String userId){
		this.userId = userId;
	}

	public String getUserId(){
		return this.userId;
	}

	public void setUserIdFuzzy(String userIdFuzzy){
		this.userIdFuzzy = userIdFuzzy;
	}

	public String getUserIdFuzzy(){
		return this.userIdFuzzy;
	}

	public void setContent(String content){
		this.content = content;
	}

	public String getContent(){
		return this.content;
	}

	public void setContentFuzzy(String contentFuzzy){
		this.contentFuzzy = contentFuzzy;
	}

	public String getContentFuzzy(){
		return this.contentFuzzy;
	}

	public void setStatus(Integer status){
		this.status = status;
	}

	public Integer getStatus(){
		return this.status;
	}

	public void setCreateTime(String createTime){
		this.createTime = createTime;
	}

	public String getCreateTime(){
		return this.createTime;
	}

	public void setCreateTimeStart(String createTimeStart){
		this.createTimeStart = createTimeStart;
	}

	public String getCreateTimeStart(){
		return this.createTimeStart;
	}
	public void setCreateTimeEnd(String createTimeEnd){
		this.createTimeEnd = createTimeEnd;
	}

	public String getCreateTimeEnd(){
		return this.createTimeEnd;
	}

}
