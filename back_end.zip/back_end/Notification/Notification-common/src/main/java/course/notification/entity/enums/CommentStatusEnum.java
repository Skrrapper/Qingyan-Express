package course.notification.entity.enums;

/**
 * 评论状态枚举类
 */
public enum CommentStatusEnum {
    NORMAL(0, "正常"),
    DELETED(1, "删除");

    private Integer type;
    private String desc;

    CommentStatusEnum(Integer type, String desc) {
        this.type = type;
        this.desc = desc;
    }

    public static CommentStatusEnum getEnumByType(Integer type) {
        for (CommentStatusEnum statusEnum : CommentStatusEnum.values()) {
            if (statusEnum.getType().equals(type)) {
                return statusEnum;
            }
        }
        return null;
    }

    public Integer getType() {
        return type;
    }

    public String getDesc() {
        return desc;
    }
}
