package course.notification.service.impl;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.mail.internet.MimeMessage;

import course.notification.entity.config.EmailConfig;
import course.notification.entity.constants.Constants;
import course.notification.entity.enums.AnnouncementStatusEnum;
import course.notification.entity.enums.CheckStatusEnum;
import course.notification.entity.po.Announcements;
import course.notification.entity.po.UserInfo;
import course.notification.entity.query.AnnouncementsQuery;
import course.notification.entity.vo.AnnouncementsVo;
import course.notification.entity.vo.CheckTableVo;
import course.notification.exception.BusinessException;
import course.notification.mappers.AnnouncementsMapper;
import course.notification.service.AnnouncementsService;
import course.notification.utils.CopyTools;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import course.notification.entity.enums.PageSize;
import course.notification.entity.query.CheckTableQuery;
import course.notification.entity.po.CheckTable;
import course.notification.entity.vo.PaginationResultVO;
import course.notification.entity.query.SimplePage;
import course.notification.mappers.CheckTableMapper;
import course.notification.service.CheckTableService;
import course.notification.utils.StringTools;


/**
 * 审核表 业务接口实现
 */
@Service("checkTableService")
public class CheckTableServiceImpl implements CheckTableService {
    private static final Logger logger = LoggerFactory.getLogger(EmailCodeServiceImpl.class);

    @Resource
    private CheckTableMapper<CheckTable, CheckTableQuery> checkTableMapper;

    @Resource
    private AnnouncementsMapper<Announcements, AnnouncementsQuery> announcementsMapper;

    @Resource
    private JavaMailSender javaMailSender;

    @Resource
    private EmailConfig emailConfig;
    @Autowired
    private UserInfoServiceImpl userInfoService;

    /**
     * 根据条件查询列表
     */
    @Override
    public List<CheckTable> findListByParam(CheckTableQuery param) {
        return this.checkTableMapper.selectList(param);
    }

    /**
     * 根据条件查询列表
     */
    @Override
    public Integer findCountByParam(CheckTableQuery param) {
        return this.checkTableMapper.selectCount(param);
    }

    /**
     * 分页查询方法
     */
    @Override
    public PaginationResultVO<CheckTable> findListByPage(CheckTableQuery param) {
        int count = this.findCountByParam(param);
        int pageSize = param.getPageSize() == null ? PageSize.SIZE15.getSize() : param.getPageSize();

        SimplePage page = new SimplePage(param.getPageNo(), count, pageSize);
        param.setSimplePage(page);
        List<CheckTable> list = this.findListByParam(param);
        PaginationResultVO<CheckTable> result = new PaginationResultVO(count, page.getPageSize(), page.getPageNo(), page.getPageTotal(), list);
        return result;
    }

    /**
     * 新增
     */
    @Override
    public Integer add(CheckTable bean) {
        return this.checkTableMapper.insert(bean);
    }

    /**
     * 批量新增
     */
    @Override
    public Integer addBatch(List<CheckTable> listBean) {
        if (listBean == null || listBean.isEmpty()) {
            return 0;
        }
        return this.checkTableMapper.insertBatch(listBean);
    }

    /**
     * 批量新增或者修改
     */
    @Override
    public Integer addOrUpdateBatch(List<CheckTable> listBean) {
        if (listBean == null || listBean.isEmpty()) {
            return 0;
        }
        return this.checkTableMapper.insertOrUpdateBatch(listBean);
    }

    /**
     * 多条件更新
     */
    @Override
    public Integer updateByParam(CheckTable bean, CheckTableQuery param) {
        StringTools.checkParam(param);
        return this.checkTableMapper.updateByParam(bean, param);
    }

    /**
     * 多条件删除
     */
    @Override
    public Integer deleteByParam(CheckTableQuery param) {
        StringTools.checkParam(param);
        return this.checkTableMapper.deleteByParam(param);
    }

    /**
     * 根据CheckId获取对象
     */
    @Override
    public CheckTable getCheckTableByCheckId(String checkId) {
        return this.checkTableMapper.selectByCheckId(checkId);
    }

    /**
     * 根据CheckId修改
     */
    @Override
    public Integer updateCheckTableByCheckId(CheckTable bean, String checkId) {
        return this.checkTableMapper.updateByCheckId(bean, checkId);
    }

    /**
     * 根据CheckId删除
     */
    @Override
    public Integer deleteCheckTableByCheckId(String checkId) {
        return this.checkTableMapper.deleteByCheckId(checkId);
    }

    @Override
    public CheckTableVo approveAnnouncement(String checkId, Integer status) {
        CheckTable checkTable = checkTableMapper.selectByCheckId(checkId);
        if (checkTable == null) {
            throw new BusinessException("审核表不存在");
        }
        String announcementId = checkTable.getAnnouncementId();
        Announcements announcements = announcementsMapper.selectByAnnouncementId(announcementId);
        String title = announcements.getTitle();
        String uid = announcementsMapper.selectByAnnouncementId(announcementId).getUserId();
        String email = userInfoService.getUserInfoByUserId(uid).getEmail();

        if (checkTable != null && checkTable.getStatus().equals(Constants.ZERO)) {

            if(status.equals(Constants.ONE) && announcements.getStatus().equals(Constants.ONE)) {
                checkTable.setStatus(status);
                checkTableMapper.updateByCheckId(checkTable, checkId);
            } else if (status.equals(Constants.TWO) && announcements.getStatus().equals(Constants.ONE)){
                checkTable.setStatus(status);
                checkTableMapper.updateByCheckId(checkTable, checkId);
                announcements.setStatus(AnnouncementStatusEnum.DELETED.getStatus());
                announcementsMapper.updateByAnnouncementId(announcements, announcementId);
            } else {
                CheckTableVo checkTableVo = new CheckTableVo();
                CopyTools.copyProperties(checkTable, checkTableVo);
                checkTableVo.setTitle(title);
                checkTableVo.setMessage("审核错误");
                checkTableVo.setApproveTime(new Date());
                return checkTableVo;
            }

            // 发送审核结果邮件
            if (!email.isEmpty()) {
                sendApproveEmail(title, status, email);
            }

            CheckTableVo checkTableVo = new CheckTableVo();
            CopyTools.copyProperties(checkTable, checkTableVo);
            checkTableVo.setTitle(title);
            CheckStatusEnum statusEnum = CheckStatusEnum.getEnumByType(status);
            if (statusEnum != null) {
                checkTableVo.setMessage(statusEnum.getDesc());
            } else {
                checkTableVo.setMessage("未知状态");
            }
            checkTableVo.setApproveTime(new Date());
            return checkTableVo;
        } else {
            CheckTableVo checkTableVo = new CheckTableVo();
            CopyTools.copyProperties(checkTable, checkTableVo);
            checkTableVo.setTitle(title);
            checkTableVo.setMessage("审核出现问题");
            checkTableVo.setApproveTime(new Date());
            return checkTableVo;
        }
    }

    private void sendApproveEmail(String title, Integer status, String toEmail) {
        try {
            CheckStatusEnum statusEnum = CheckStatusEnum.getEnumByType(status);
            if (statusEnum != null) {
                MimeMessage message = javaMailSender.createMimeMessage();
                MimeMessageHelper helper = new MimeMessageHelper(message, true);
                helper.setFrom(emailConfig.getSendUsername());
                helper.setTo(toEmail);
                helper.setSubject("青言速递 公告审核信息");
                
                // 读取邮件模板
                String templatePath = "static/approve/approveAnnouncement.html";
                // 获取项目根路径
                String projectPath = System.getProperty("user.dir");
                String fullPath = projectPath + File.separator + templatePath;

                String htmlContent = new String(Files.readAllBytes(Paths.get(fullPath)), "UTF-8");

                String statusText = statusEnum.getDesc();
                String statusClass = status == CheckStatusEnum.APPROVED.getType() ? "status-pass" : "status-reject";
                String publishNote = status == CheckStatusEnum.APPROVED.getType() ? 
                    "您的公告已发布至公告栏" : "您的公告未通过审核";
                
                htmlContent = htmlContent.replace("status-pass", statusClass)
                                         .replace("审核通过", statusText)
                                         .replace("学期末考试安排通知", title)
                                         .replace("您的公告已发布至公告栏", publishNote);
                
                helper.setText(htmlContent, true);
                javaMailSender.send(message);
                logger.info("审核通知邮件发送成功，收件人：{}", toEmail);
            }
        } catch (Exception e) {
            logger.error("邮件发送失败", e);
            throw new BusinessException("邮件发送失败");
        }
    }

    public List<Announcements> selectCheckTableWithNotApprove(AnnouncementsQuery param) {
        return this.announcementsMapper.selectCheckTableWithNotApprove(param);
    }

    public PaginationResultVO<Announcements> selectCheckTableWithNotApproveByPage(AnnouncementsQuery param) {
        int count = announcementsMapper.selectCount(param);
        int pageSize = param.getPageSize() == null ? PageSize.SIZE15.getSize() : param.getPageSize();

        SimplePage page = new SimplePage(param.getPageNo(), count, pageSize);
        param.setSimplePage(page);
        List<Announcements> list = this.selectCheckTableWithNotApprove(param);
        return new PaginationResultVO<>(count, page.getPageSize(), page.getPageNo(), page.getPageTotal(), list);
    }

    @Override
    public PaginationResultVO<AnnouncementsVo> getApproveList(Integer pageNum, Integer pageSize) {
        AnnouncementsQuery query = new AnnouncementsQuery();
        query.setPageNo(pageNum);
        query.setPageSize(pageSize);
        query.setStatus(AnnouncementStatusEnum.PUBLISHED.getStatus());
        PaginationResultVO<Announcements> announcementsPaginationResultVO = this.selectCheckTableWithNotApproveByPage(query);
        List<Announcements> announcementsList = announcementsPaginationResultVO.getList();
        List<AnnouncementsVo> announcementsVoList = new ArrayList<>();
        for (Announcements announcements : announcementsList) {
            AnnouncementsVo announcementsVo = new AnnouncementsVo();
            CopyTools.copyProperties(announcements, announcementsVo);
            UserInfo userInfo = userInfoService.getUserInfoByUserId(announcements.getUserId());
            announcementsVo.setNickName(userInfo.getNickName());
            announcementsVo.setAvatar(userInfo.getAvatar());

            announcementsVoList.add(announcementsVo);
        }

        return new PaginationResultVO<>(announcementsPaginationResultVO.getTotalCount(), pageSize, pageNum, announcementsVoList);
    }
}