package course.notification.entity.enums;

public enum AnnouncementTopEnum {

    NOT_TOP(0, "否"),
    TOP(1, "是");

    private Integer top;
    private String desc;

    AnnouncementTopEnum(Integer top, String desc) {
        this.top = top;
        this.desc = desc;
    }

    public static AnnouncementTopEnum getByTop(Integer top) {
        for (AnnouncementTopEnum announcementTopEnum : AnnouncementTopEnum.values()) {
            if (announcementTopEnum.getTop().equals(top)) {
                return announcementTopEnum;
            }
        }
        return null;
    }

    public Integer getTop() {
        return top;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
