package course.notification.entity.enums;

public enum AnnouncementStatusEnum {

    DRAFT(0, "草稿"),
    PUBLISHED(1, "发布"),
    DELETED(2, "删除");

    private Integer status;
    private String desc;

    AnnouncementStatusEnum(Integer status, String desc) {
        this.status = status;
        this.desc = desc;
    }

    public static AnnouncementStatusEnum getByStatus(Integer status) {
        for (AnnouncementStatusEnum announcementStatusEnum : AnnouncementStatusEnum.values()) {
            if (announcementStatusEnum.getStatus().equals(status)) {
                return announcementStatusEnum;
            }
        }
        return null;
    }

    public Integer getStatus() {
        return status;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
