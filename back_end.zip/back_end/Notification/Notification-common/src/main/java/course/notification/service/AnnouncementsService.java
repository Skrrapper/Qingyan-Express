package course.notification.service;

import java.util.List;

import course.notification.entity.dto.AnnouncementDto;
import course.notification.entity.query.AnnouncementsQuery;
import course.notification.entity.po.Announcements;
import course.notification.entity.vo.AnnouncementsDetailVo;
import course.notification.entity.vo.AnnouncementsVo;
import course.notification.entity.vo.PaginationResultVO;


/**
 * 公告表 业务接口
 */
public interface AnnouncementsService {

    /**
     * 根据条件查询列表
     */
    List<Announcements> findListByParam(AnnouncementsQuery param);

    /**
     * 根据条件查询列表
     */
    Integer findCountByParam(AnnouncementsQuery param);

    /**
     * 分页查询
     */
    PaginationResultVO<Announcements> findListByPage(AnnouncementsQuery param);

    /**
     * 新增
     */
    Integer add(Announcements bean);

    /**
     * 批量新增
     */
    Integer addBatch(List<Announcements> listBean);

    /**
     * 批量新增/修改
     */
    Integer addOrUpdateBatch(List<Announcements> listBean);

    /**
     * 多条件更新
     */
    Integer updateByParam(Announcements bean, AnnouncementsQuery param);

    /**
     * 多条件删除
     */
    Integer deleteByParam(AnnouncementsQuery param);

    /**
     * 根据AnnouncementId查询对象
     */
    Announcements getAnnouncementsByAnnouncementId(String announcementId);


    /**
     * 根据AnnouncementId修改
     */
    Integer updateAnnouncementsByAnnouncementId(Announcements bean, String announcementId);


    /**
     * 根据AnnouncementId删除
     */
    Integer deleteAnnouncementsByAnnouncementId(String announcementId);

    // 编辑公告(草稿)
    AnnouncementDto addAnnouncement(String userId, String title, String content);

    // 发布公告
    AnnouncementDto publishAnnouncement(String userId, String announcementId);

    // 删除公告
    AnnouncementDto deleteAnnouncement(String userId, String announcementId);

    // 修改公告内容
    AnnouncementDto updateAnnouncement(String userId, String announcementId, String title, String content);

    // 获取公告列表（日期排序）
    PaginationResultVO<AnnouncementsVo> getAnnouncementListByDate(Integer pageNum, Integer pageSize, Integer way);

    // 获取公告列表（浏览量排序）
    PaginationResultVO<AnnouncementsVo> getAnnouncementListByViewCount(Integer pageNum, Integer pageSize, Integer way);

    // 浏览公告
    AnnouncementsDetailVo viewAnnouncement(String announcementId);

    PaginationResultVO<AnnouncementsVo> loadDataList(String userId, AnnouncementsQuery query, Integer pageNum, Integer pageSize);

    PaginationResultVO<AnnouncementsVo> searchAnnouncement(AnnouncementsQuery query, Integer pageNum, Integer pageSize);
}