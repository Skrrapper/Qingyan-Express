package course.notification.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import javax.annotation.Resource;

import course.notification.entity.constants.Constants;
import course.notification.entity.dto.AnnouncementDto;
import course.notification.entity.enums.AnnouncementStatusEnum;
import course.notification.entity.enums.AnnouncementTopEnum;
import course.notification.entity.enums.CheckStatusEnum;
import course.notification.entity.po.CheckTable;
import course.notification.entity.po.UserInfo;
import course.notification.entity.query.CheckTableQuery;
import course.notification.entity.vo.AnnouncementsDetailVo;
import course.notification.entity.vo.AnnouncementsVo;
import course.notification.exception.BusinessException;
import course.notification.service.CheckTableService;
import course.notification.service.UserInfoService;
import course.notification.utils.CopyTools;
import org.springframework.stereotype.Service;

import course.notification.entity.enums.PageSize;
import course.notification.entity.query.AnnouncementsQuery;
import course.notification.entity.po.Announcements;
import course.notification.entity.vo.PaginationResultVO;
import course.notification.entity.query.SimplePage;
import course.notification.mappers.AnnouncementsMapper;
import course.notification.service.AnnouncementsService;
import course.notification.utils.StringTools;
import org.springframework.transaction.annotation.Transactional;


/**
 * 公告表 业务接口实现
 */
@Service("announcementsService")
public class AnnouncementsServiceImpl implements AnnouncementsService {

    @Resource
    private AnnouncementsMapper<Announcements, AnnouncementsQuery> announcementsMapper;

    @Resource
    private UserInfoService userInfoService;

    @Resource
    private CheckTableService checkTableService;

    /**
     * 根据条件查询列表
     */
    @Override
    public List<Announcements> findListByParam(AnnouncementsQuery param) {
        return this.announcementsMapper.selectListFromCheckTable(param);
    }

    public List<Announcements> findListByParamNormal(AnnouncementsQuery param) {
        return this.announcementsMapper.selectList(param);
    }

    /**
     * 根据条件查询列表
     */
    @Override
    public Integer findCountByParam(AnnouncementsQuery param) {
        return this.announcementsMapper.selectCount(param);
    }

    /**
     * 分页查询方法
     */
    @Override
    public PaginationResultVO<Announcements> findListByPage(AnnouncementsQuery param) {
        int count = this.findCountByParam(param);
        int pageSize = param.getPageSize() == null ? PageSize.SIZE15.getSize() : param.getPageSize();

        SimplePage page = new SimplePage(param.getPageNo(), count, pageSize);
        param.setSimplePage(page);
        List<Announcements> list = this.findListByParam(param);
        return new PaginationResultVO<>(count, page.getPageSize(), page.getPageNo(), page.getPageTotal(), list);
    }

    public PaginationResultVO<Announcements> findListByPageNormal(AnnouncementsQuery param) {
        int count = this.findCountByParam(param);
        int pageSize = param.getPageSize() == null ? PageSize.SIZE15.getSize() : param.getPageSize();

        SimplePage page = new SimplePage(param.getPageNo(), count, pageSize);
        param.setSimplePage(page);
        List<Announcements> list = this.findListByParamNormal(param);
        return new PaginationResultVO<>(count, page.getPageSize(), page.getPageNo(), page.getPageTotal(), list);
    }

    /**
     * 新增
     */
    @Override
    public Integer add(Announcements bean) {
        return this.announcementsMapper.insert(bean);
    }

    /**
     * 批量新增
     */
    @Override
    public Integer addBatch(List<Announcements> listBean) {
        if (isNullOrEmpty(listBean)) {
            return 0;
        }
        return this.announcementsMapper.insertBatch(listBean);
    }

    /**
     * 批量新增或者修改
     */
    @Override
    public Integer addOrUpdateBatch(List<Announcements> listBean) {
        if (isNullOrEmpty(listBean)) {
            return 0;
        }
        return this.announcementsMapper.insertOrUpdateBatch(listBean);
    }

    /**
     * 多条件更新
     */
    @Override
    public Integer updateByParam(Announcements bean, AnnouncementsQuery param) {
        StringTools.checkParam(param);
        return this.announcementsMapper.updateByParam(bean, param);
    }

    /**
     * 多条件删除
     */
    @Override
    public Integer deleteByParam(AnnouncementsQuery param) {
        StringTools.checkParam(param);
        return this.announcementsMapper.deleteByParam(param);
    }

    /**
     * 根据AnnouncementId获取对象
     */
    @Override
    public Announcements getAnnouncementsByAnnouncementId(String announcementId) {
        return this.announcementsMapper.selectByAnnouncementId(announcementId);
    }

    /**
     * 根据AnnouncementId修改
     */
    @Override
    public Integer updateAnnouncementsByAnnouncementId(Announcements bean, String announcementId) {
        return this.announcementsMapper.updateByAnnouncementId(bean, announcementId);
    }

    /**
     * 根据AnnouncementId删除
     */
    @Override
    public Integer deleteAnnouncementsByAnnouncementId(String announcementId) {
        return this.announcementsMapper.deleteByAnnouncementId(announcementId);
    }

    @Override
    public AnnouncementDto addAnnouncement(String userId, String title, String content) {
        validateUserAndContent(userId, title, content);

        UserInfo userInfo = userInfoService.getUserInfoByUserId(userId);
        String announcementId = StringTools.getRandomAnnouncementId(Constants.LENGTH_9);

        Announcements announcements = new Announcements();
        announcements.setAnnouncementId(announcementId);
        announcements.setUserId(userId);
        announcements.setTitle(title);
        announcements.setContent(content);
        announcements.setStatus(AnnouncementStatusEnum.DRAFT.getStatus());
        announcements.setTop(AnnouncementTopEnum.NOT_TOP.getTop());
        announcements.setCreateTime(new Date());
        this.announcementsMapper.insert(announcements);

        AnnouncementDto announcementDto = CopyTools.copy(announcements, AnnouncementDto.class);
        announcementDto.setNickName(userInfo.getNickName());
        announcementDto.setMessage("添加成功");

        return announcementDto;
    }

    @Override
    public AnnouncementDto publishAnnouncement(String userId, String announcementId) {
        Announcements existingAnnouncement = validateAnnouncementOwnership(userId, announcementId);

        if (existingAnnouncement.getStatus() == AnnouncementStatusEnum.PUBLISHED.getStatus()) {
            throw new BusinessException("此公告已发布");
        }

        UserInfo userInfo = userInfoService.getUserInfoByUserId(userId);

        Announcements announcements = new Announcements();
        announcements.setStatus(AnnouncementStatusEnum.PUBLISHED.getStatus());
        announcements.setPublishTime(new Date());
        this.announcementsMapper.updateByAnnouncementId(announcements, announcementId);

        // 插入审核表
        CheckTable checkTable = new CheckTable();
        checkTable.setCheckId(StringTools.getRandomCheckId(Constants.LENGTH_9));
        checkTable.setAnnouncementId(announcementId);
        checkTable.setUserId(userId);
        checkTable.setStatus(CheckStatusEnum.PENDING.getType());
        checkTable.setCreateTime(new Date());
        checkTableService.add(checkTable);

        AnnouncementDto announcementDto = CopyTools.copy(announcements, AnnouncementDto.class);
        announcementDto.setNickName(userInfo.getNickName());
        announcementDto.setMessage("发布成功");

        return announcementDto;
    }

    @Override
    public AnnouncementDto deleteAnnouncement(String userId, String announcementId) {
        Announcements existingAnnouncement = validateAnnouncementOwnership(userId, announcementId);

        // 检查公告是否已被删除
        if (existingAnnouncement.getStatus() == AnnouncementStatusEnum.DELETED.getStatus()) {
            throw new BusinessException("此公告已被删除");
        }

        // 执行删除操作（状态修改为删除）
        Announcements announcements = new Announcements();
        announcements.setStatus(AnnouncementStatusEnum.DELETED.getStatus());
        this.announcementsMapper.updateByAnnouncementId(announcements, announcementId);

        // 获取用户昵称
        UserInfo userInfo = userInfoService.getUserInfoByUserId(userId);

        // 构造返回结果
        AnnouncementDto announcementDto = CopyTools.copy(announcements, AnnouncementDto.class);
        announcementDto.setNickName(userInfo.getNickName());
        announcementDto.setMessage("删除成功");

        return announcementDto;
    }

    @Override
    public AnnouncementDto updateAnnouncement(String userId, String announcementId, String title, String content) {
        // 检查参数
        validateUserAndContent(userId, title, content);

        // 检查公告是否存在和权限
        Announcements existingAnnouncement = validateAnnouncementOwnership(userId, announcementId);

        // 检查公告是否已被删除
        if (existingAnnouncement.getStatus() == AnnouncementStatusEnum.DELETED.getStatus()) {
            throw new BusinessException("公告已被删除，无法修改");
        }

        // 更新公告内容
        Announcements announcements = new Announcements();
        announcements.setTitle(title);
        announcements.setContent(content);

        // 如果公告已发布，更新发布时间
        if (existingAnnouncement.getStatus() == AnnouncementStatusEnum.PUBLISHED.getStatus()) {
            announcements.setPublishTime(new Date());
        }

        this.announcementsMapper.updateByAnnouncementId(announcements, announcementId);

        // 如果公告已发布，需要重新审核
        if (existingAnnouncement.getStatus() == AnnouncementStatusEnum.PUBLISHED.getStatus()) {
            handleReviewProcess(announcementId, userId);
        }

        // 获取用户昵称
        UserInfo userInfo = userInfoService.getUserInfoByUserId(userId);

        // 构造返回结果
        AnnouncementDto announcementDto = CopyTools.copy(announcements, AnnouncementDto.class);
        announcementDto.setNickName(userInfo.getNickName());
        announcementDto.setMessage("修改成功");

        return announcementDto;
    }

    @Override
    public PaginationResultVO<AnnouncementsVo> getAnnouncementListByDate(Integer pageNum, Integer pageSize, Integer way) {
        AnnouncementsQuery announcementsQuery = createBaseQuery(pageNum, pageSize);
        announcementsQuery.setOrderBy(getOrderByClause("publish_time", way));

        return convertToAnnouncementsVoResult(this.findListByPage(announcementsQuery));
    }

    @Override
    public PaginationResultVO<AnnouncementsVo> getAnnouncementListByViewCount(Integer pageNum, Integer pageSize, Integer way) {
        AnnouncementsQuery announcementsQuery = createBaseQuery(pageNum, pageSize);
        announcementsQuery.setOrderBy(getOrderByClause("view_count", way));

        return convertToAnnouncementsVoResult(this.findListByPage(announcementsQuery));
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public AnnouncementsDetailVo viewAnnouncement(String announcementId) {
        Announcements announcements = this.getAnnouncementsByAnnouncementId(announcementId);
        if (announcements == null) {
            throw new BusinessException("公告不存在");
        }

        announcements.setViewCount(announcements.getViewCount() + 1);
        this.updateAnnouncementsByAnnouncementId(announcements, announcementId);

        AnnouncementsDetailVo announcementsDetailVo = CopyTools.copy(announcements, AnnouncementsDetailVo.class);
        enrichWithUserInfo(announcementsDetailVo, announcements.getUserId());

        return announcementsDetailVo;
    }

    private void enrichWithUserInfo(AnnouncementsDetailVo vo, String userId) {
        UserInfo userInfo = userInfoService.getUserInfoByUserId(userId);
        if (userInfo != null) {
            vo.setNickName(userInfo.getNickName());
            vo.setAvatar(userInfo.getAvatar());
        }
    }


    @Override
    public PaginationResultVO<AnnouncementsVo> loadDataList(String userId, AnnouncementsQuery query, Integer pageNum, Integer pageSize) {
        query.setUserId(userId);
        query.setPageNo(pageNum);
        query.setPageSize(pageSize);
        PaginationResultVO<Announcements> result = this.findListByPageNormal(query);

        return convertToAnnouncementsVoResult(result);
    }

    @Override
    public PaginationResultVO<AnnouncementsVo> searchAnnouncement(AnnouncementsQuery query, Integer pageNum, Integer pageSize) {
        query.setPageNo(pageNum);
        query.setPageSize(pageSize);
        query.setStatus(AnnouncementStatusEnum.PUBLISHED.getStatus());
        PaginationResultVO<Announcements> result = this.findListByPage(query);

        if (result.getList().isEmpty()) {
            return null;
        }

        return convertToAnnouncementsVoResult(result);
    }

    // 私有辅助方法

    private boolean isNullOrEmpty(List<?> list) {
        return list == null || list.isEmpty();
    }

    private void validateUserAndContent(String userId, String title, String content) {
        if (StringTools.isEmpty(userId)) {
            throw new BusinessException("用户不存在，请先登录");
        }
        if (StringTools.isEmpty(title)) {
            throw new BusinessException("标题不能为空");
        }
        if (StringTools.isEmpty(content)) {
            throw new BusinessException("内容不能为空");
        }
    }

    private Announcements validateAnnouncementOwnership(String userId, String announcementId) {
        Announcements existingAnnouncement = announcementsMapper.selectByAnnouncementId(announcementId);
        if (existingAnnouncement == null) {
            throw new BusinessException("公告不存在");
        }
        if (!existingAnnouncement.getUserId().equals(userId)) {
            throw new BusinessException("您没有权限修改此公告");
        }
        return existingAnnouncement;
    }

    private void handleReviewProcess(String announcementId, String userId) {
        // 查找该公告是否已有审核记录
        CheckTableQuery checkTableQuery = new CheckTableQuery();
        checkTableQuery.setAnnouncementId(announcementId);
        List<CheckTable> checkTableList = checkTableService.findListByParam(checkTableQuery);

        if (checkTableList != null && !checkTableList.isEmpty()) {
            // 如果存在审核记录，更新第一条记录为待审核状态
            CheckTable existingCheckTable = checkTableList.get(0);
            existingCheckTable.setStatus(CheckStatusEnum.PENDING.getType());
            existingCheckTable.setCreateTime(new Date());
            checkTableService.updateCheckTableByCheckId(existingCheckTable, existingCheckTable.getCheckId());
        } else {
            // 如果不存在审核记录，插入新的审核记录
            CheckTable checkTable = new CheckTable();
            checkTable.setCheckId(StringTools.getRandomCheckId(Constants.LENGTH_9));
            checkTable.setAnnouncementId(announcementId);
            checkTable.setUserId(userId);
            checkTable.setStatus(CheckStatusEnum.PENDING.getType());
            checkTable.setCreateTime(new Date());
            checkTableService.add(checkTable);
        }
    }

    private AnnouncementsQuery createBaseQuery(Integer pageNum, Integer pageSize) {
        AnnouncementsQuery query = new AnnouncementsQuery();
        query.setStatus(AnnouncementStatusEnum.PUBLISHED.getStatus());
        query.setPageNo(pageNum);
        query.setPageSize(pageSize);
        return query;
    }

    private String getOrderByClause(String field, Integer way) {
        return way == 1 ? field + " asc" : field + " desc";
    }

    private void enrichWithUserInfo(AnnouncementsVo vo, String userId) {
        UserInfo userInfo = userInfoService.getUserInfoByUserId(userId);
        if (userInfo != null) {
            vo.setNickName(userInfo.getNickName());
            vo.setAvatar(userInfo.getAvatar());
        }
    }

    private PaginationResultVO<AnnouncementsVo> convertToAnnouncementsVoResult(PaginationResultVO<Announcements> result) {
        List<AnnouncementsVo> voList = result.getList().stream().map(announcement -> {
            AnnouncementsVo vo = CopyTools.copy(announcement, AnnouncementsVo.class);
            enrichWithUserInfo(vo, announcement.getUserId());
            return vo;
        }).collect(Collectors.toList());

        return new PaginationResultVO<>(
                result.getTotalCount(),
                result.getPageSize(),
                result.getPageNo(),
                result.getPageTotal(),
                voList
        );
    }
}
