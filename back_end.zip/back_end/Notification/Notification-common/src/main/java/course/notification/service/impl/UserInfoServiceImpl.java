package course.notification.service.impl;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import course.notification.component.RedisComponent;
import course.notification.entity.config.AppConfig;
import course.notification.entity.constants.Constants;
import course.notification.entity.dto.TokenUserInfoDto;
import course.notification.entity.enums.UserRoleEnum;
import course.notification.entity.enums.UserSexEnum;
import course.notification.entity.enums.UserStatusEnum;
import course.notification.exception.BusinessException;
import course.notification.service.EmailCodeService;
import course.notification.utils.CopyTools;
import org.apache.commons.io.FilenameUtils;
import org.springframework.stereotype.Service;

import course.notification.entity.enums.PageSize;
import course.notification.entity.query.UserInfoQuery;
import course.notification.entity.po.UserInfo;
import course.notification.entity.vo.PaginationResultVO;
import course.notification.entity.query.SimplePage;
import course.notification.mappers.UserInfoMapper;
import course.notification.service.UserInfoService;
import course.notification.utils.StringTools;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;


/**
 *  业务接口实现
 */
@Service("userInfoService")
public class UserInfoServiceImpl implements UserInfoService {

	@Resource
	private RedisComponent redisComponent;

	@Resource
	private EmailCodeService emailCodeService;

	@Resource
	private AppConfig appConfig;

	@Resource
	private UserInfoMapper<UserInfo, UserInfoQuery> userInfoMapper;

	/**
	 * 根据条件查询列表
	 */
	@Override
	public List<UserInfo> findListByParam(UserInfoQuery param) {
		return this.userInfoMapper.selectList(param);
	}

	/**
	 * 根据条件查询列表
	 */
	@Override
	public Integer findCountByParam(UserInfoQuery param) {
		return this.userInfoMapper.selectCount(param);
	}

	/**
	 * 分页查询方法
	 */
	@Override
	public PaginationResultVO<UserInfo> findListByPage(UserInfoQuery param) {
		int count = this.findCountByParam(param);
		int pageSize = param.getPageSize() == null ? PageSize.SIZE15.getSize() : param.getPageSize();

		SimplePage page = new SimplePage(param.getPageNo(), count, pageSize);
		param.setSimplePage(page);
		List<UserInfo> list = this.findListByParam(param);
		PaginationResultVO<UserInfo> result = new PaginationResultVO(count, page.getPageSize(), page.getPageNo(), page.getPageTotal(), list);
		return result;
	}

	/**
	 * 新增
	 */
	@Override
	public Integer add(UserInfo bean) {
		return this.userInfoMapper.insert(bean);
	}

	/**
	 * 批量新增
	 */
	@Override
	public Integer addBatch(List<UserInfo> listBean) {
		if (listBean == null || listBean.isEmpty()) {
			return 0;
		}
		return this.userInfoMapper.insertBatch(listBean);
	}

	/**
	 * 批量新增或者修改
	 */
	@Override
	public Integer addOrUpdateBatch(List<UserInfo> listBean) {
		if (listBean == null || listBean.isEmpty()) {
			return 0;
		}
		return this.userInfoMapper.insertOrUpdateBatch(listBean);
	}

	/**
	 * 多条件更新
	 */
	@Override
	public Integer updateByParam(UserInfo bean, UserInfoQuery param) {
		StringTools.checkParam(param);
		return this.userInfoMapper.updateByParam(bean, param);
	}

	/**
	 * 多条件删除
	 */
	@Override
	public Integer deleteByParam(UserInfoQuery param) {
		StringTools.checkParam(param);
		return this.userInfoMapper.deleteByParam(param);
	}

	/**
	 * 根据UserId获取对象
	 */
	@Override
	public UserInfo getUserInfoByUserId(String userId) {
		return this.userInfoMapper.selectByUserId(userId);
	}

	/**
	 * 根据UserId修改
	 */
	@Override
	public Integer updateUserInfoByUserId(UserInfo bean, String userId) {
		return this.userInfoMapper.updateByUserId(bean, userId);
	}

	/**
	 * 根据UserId删除
	 */
	@Override
	public Integer deleteUserInfoByUserId(String userId) {
		return this.userInfoMapper.deleteByUserId(userId);
	}

	/**
	 * 根据Email获取对象
	 */
	@Override
	public UserInfo getUserInfoByEmail(String email) {
		return this.userInfoMapper.selectByEmail(email);
	}

	/**
	 * 根据Email修改
	 */
	@Override
	public Integer updateUserInfoByEmail(UserInfo bean, String email) {
		return this.userInfoMapper.updateByEmail(bean, email);
	}

	/**
	 * 根据Email删除
	 */
	@Override
	public Integer deleteUserInfoByEmail(String email) {
		return this.userInfoMapper.deleteByEmail(email);
	}

	/**
	 * 根据NickName获取对象
	 */
	@Override
	public UserInfo getUserInfoByNickName(String nickName) {
		return this.userInfoMapper.selectByNickName(nickName);
	}

	/**
	 * 根据NickName修改
	 */
	@Override
	public Integer updateUserInfoByNickName(UserInfo bean, String nickName) {
		return this.userInfoMapper.updateByNickName(bean, nickName);
	}

	/**
	 * 根据NickName删除
	 */
	@Override
	public Integer deleteUserInfoByNickName(String nickName) {
		return this.userInfoMapper.deleteByNickName(nickName);
	}

	@Override
	public void register(String email, String nickName, String registerPassword) {
		UserInfo userInfo = this.userInfoMapper.selectByEmail(email);
		if (userInfo != null) {
			throw new BusinessException("邮箱账号已经存在");
		}
		UserInfo nickNameUserInfo = this.userInfoMapper.selectByNickName(nickName);
		if (nickNameUserInfo != null) {
			throw new BusinessException("昵称已经存在");
		}

		userInfo = new UserInfo();
		String userId = StringTools.getRandomUserId(Constants.LENGTH_9);
		userInfo.setUserId(userId);
		userInfo.setEmail(email);
		userInfo.setNickName(nickName);
		userInfo.setAvatar(Constants.AVATAR_DEFAULT);
		userInfo.setPassword(StringTools.encodeByMD5(registerPassword));
		userInfo.setCreateTime(new Date());
		userInfo.setStatus(UserStatusEnum.ENABLE.getStatus());
		userInfo.setSex(UserSexEnum.SECRECY.getType());
		userInfo.setRole(UserRoleEnum.STUDENT.getType());

		this.userInfoMapper.insert(userInfo);
	}

	@Override
	public TokenUserInfoDto login(String email, String password) {
		UserInfo userInfo = this.userInfoMapper.selectByEmail(email);
		if(null == userInfo || !userInfo.getPassword().equals(StringTools.encodeByMD5(password))){
			throw new BusinessException("邮箱账号或者密码错误");
		}
		if(UserStatusEnum.DISABLE.getStatus().equals(userInfo.getStatus())){
			throw new BusinessException("账号已被禁用");
		}
		return getTokenUserInfoDto(userInfo);
	}

	@Override
	public TokenUserInfoDto EmailLogin(String email, String emailCode) {
		UserInfo userInfo = this.userInfoMapper.selectByEmail(email);
		if(null == userInfo){
			throw new BusinessException("邮箱账号或者验证码错误");
		}
		if(UserStatusEnum.DISABLE.getStatus().equals(userInfo.getStatus())){
			throw new BusinessException("账号已被禁用");
		}

		// 校验邮箱验证码
		emailCodeService.checkCode(email, emailCode);

		return getTokenUserInfoDto(userInfo);
	}

	// 获取TokenUserInfoDto
	private TokenUserInfoDto getTokenUserInfoDto(UserInfo userInfo) {
		TokenUserInfoDto tokenUserInfoDto = CopyTools.copy(userInfo, TokenUserInfoDto.class);
		redisComponent.saveTokenInfo(tokenUserInfoDto);
		return tokenUserInfoDto;
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public void resetPwd(String email, String password, String emailCode) {
		UserInfo userInfo = this.userInfoMapper.selectByEmail(email);

		if(userInfo == null){
			throw new BusinessException("邮箱账号不存在");
		}
		if(UserStatusEnum.DISABLE.getStatus().equals(userInfo.getStatus())){
			throw new BusinessException("账号已被禁用");
		}

		emailCodeService.checkCode(email, emailCode);

		UserInfo updateUserInfo = new UserInfo();
		updateUserInfo.setPassword(StringTools.encodeByMD5(password));
		this.userInfoMapper.updateByEmail(updateUserInfo, email);
	}

	@Override
	public String uploadAvatar(MultipartFile file, String userId) throws BusinessException {
		try {
			// 1. 校验文件
			if (file.isEmpty()) {
				throw new BusinessException("上传文件不能为空");
			}

			// 2. 生成存储路径（建议配置化）
			String uploadDir = appConfig.getProjectFolder() + "/static/avatars/"; // 改为你的存储路径
			String suffix = FilenameUtils.getExtension(file.getOriginalFilename());
			String fileName = userId + "_" + System.currentTimeMillis() + "." + suffix;
			Path filePath = Paths.get(uploadDir + fileName);

			// 3. 保存文件
			Files.createDirectories(filePath.getParent());
			file.transferTo(filePath);

			// 4. 更新数据库
			UserInfo userInfo = new UserInfo();
			userInfo.setAvatar(fileName); // 存储相对路径

			userInfoMapper.updateByUserId(userInfo, userId);

			return fileName;
		} catch (IOException e) {
			throw new BusinessException("头像上传失败：" + e.getMessage());
		}
	}

	@Override
	public String getAvatar(String userId) {
		UserInfo userInfo = userInfoMapper.selectByUserId(userId);
		return (userInfo != null && !StringTools.isEmpty(userInfo.getAvatar()))
				? appConfig.getProjectFolder() +"/static/avatars/" + userInfo.getAvatar()
				: null;
	}
}