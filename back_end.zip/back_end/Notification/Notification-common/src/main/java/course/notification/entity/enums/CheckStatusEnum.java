package course.notification.entity.enums;

/**
 * 审核状态枚举类
 */
public enum CheckStatusEnum {
    PENDING(0, "待审核"),
    APPROVED(1, "审批通过"),
    REJECTED(2, "拒绝通过");

    private Integer type;
    private String desc;

    CheckStatusEnum(Integer type, String desc) {
        this.type = type;
        this.desc = desc;
    }

    /**
     * 根据类型获取枚举值
     *
     * @param type 类型值
     * @return 对应的枚举对象，找不到则返回 null
     */
    public static CheckStatusEnum getEnumByType(Integer type) {
        for (CheckStatusEnum checkStatusEnum : CheckStatusEnum.values()) {
            if (checkStatusEnum.getType().equals(type)) {
                return checkStatusEnum;
            }
        }
        return null;
    }

    public Integer getType() {
        return type;
    }

    public String getDesc() {
        return desc;
    }
}
