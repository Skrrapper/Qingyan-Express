package course.notification.entity.query;

import java.util.Date;


/**
 * 审核表参数
 */
public class CheckTableQuery extends BaseParam {


	/**
	 * 审核id
	 */
	private String checkId;

	private String checkIdFuzzy;

	/**
	 * 公告id
	 */
	private String announcementId;

	private String announcementIdFuzzy;

	/**
	 * 审核人id
	 */
	private String userId;

	private String userIdFuzzy;

	/**
	 * 状态(0:待审核 1:通过 2:拒绝)
	 */
	private Integer status;

	/**
	 * 创建时间
	 */
	private String createTime;

	private String createTimeStart;

	private String createTimeEnd;


	public void setCheckId(String checkId){
		this.checkId = checkId;
	}

	public String getCheckId(){
		return this.checkId;
	}

	public void setCheckIdFuzzy(String checkIdFuzzy){
		this.checkIdFuzzy = checkIdFuzzy;
	}

	public String getCheckIdFuzzy(){
		return this.checkIdFuzzy;
	}

	public void setAnnouncementId(String announcementId){
		this.announcementId = announcementId;
	}

	public String getAnnouncementId(){
		return this.announcementId;
	}

	public void setAnnouncementIdFuzzy(String announcementIdFuzzy){
		this.announcementIdFuzzy = announcementIdFuzzy;
	}

	public String getAnnouncementIdFuzzy(){
		return this.announcementIdFuzzy;
	}

	public void setUserId(String userId){
		this.userId = userId;
	}

	public String getUserId(){
		return this.userId;
	}

	public void setUserIdFuzzy(String userIdFuzzy){
		this.userIdFuzzy = userIdFuzzy;
	}

	public String getUserIdFuzzy(){
		return this.userIdFuzzy;
	}

	public void setStatus(Integer status){
		this.status = status;
	}

	public Integer getStatus(){
		return this.status;
	}

	public void setCreateTime(String createTime){
		this.createTime = createTime;
	}

	public String getCreateTime(){
		return this.createTime;
	}

	public void setCreateTimeStart(String createTimeStart){
		this.createTimeStart = createTimeStart;
	}

	public String getCreateTimeStart(){
		return this.createTimeStart;
	}
	public void setCreateTimeEnd(String createTimeEnd){
		this.createTimeEnd = createTimeEnd;
	}

	public String getCreateTimeEnd(){
		return this.createTimeEnd;
	}

}
