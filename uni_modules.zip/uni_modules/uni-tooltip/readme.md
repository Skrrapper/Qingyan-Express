## Badge 数字角标
> **组件名：uni-tooltip**
> 代码块： `uTooltip`

数字角标一般和其它控件（列表、9宫格等）配合使用，用于进行数量提示，默认为实心灰色背景，

### [查看文档](https://uniapp.dcloud.io/component/uniui/uni-tooltip)
#### 如使用过程中有任何问题，或者您对uni-ui有一些好的建议，欢迎加入 uni-ui 交流群：871950839 
